<?php
namespace Swift\CustomCustomer\Plugin\Controller\Account;

class LoginPost
{
    public $data;
    public $url;
    public $responseFactory;
    public $messageManager;

    public function __construct(
        \Swift\Core\Helper\Data $data,
        \Magento\Framework\UrlInterface $url,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\Message\ManagerInterface $messageManager
    ) {
        $this->data = $data;
        $this->url = $url;
        $this->responseFactory = $responseFactory;
        $this->messageManager = $messageManager;
    }
    
    public function beforeExecute(\Magento\Customer\Controller\Account\LoginPost $subject)
    {
        if (!$this->data->isLicenseValid($this->data->getLicense())) {
            $this->messageManager->addError(__('License is not valid.'));
            
            $redirectionUrl = $this->url->getUrl('customer/account/login');
            $this->responseFactory->create()->setRedirect($redirectionUrl)->sendResponse();
            exit;
        }
    }
}