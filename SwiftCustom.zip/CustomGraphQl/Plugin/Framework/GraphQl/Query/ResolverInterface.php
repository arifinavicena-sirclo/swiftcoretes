<?php
namespace Swift\CustomGraphQl\Plugin\Framework\GraphQl\Query;

class ResolverInterface
{
    public $data;

    public function __construct(
        \Swift\Core\Helper\Data $data
    ) {
        $this->data = $data;
    }
    
    public function beforeResolve(
        \Magento\Framework\GraphQl\Query\ResolverInterface $subject,
        $field,
        $context,
        $info,
        $value,
        $args
    ) {
        if (!$this->data->isLicenseValid($this->data->getLicense())) {
            throw new \Magento\Framework\GraphQl\Exception\GraphQlAuthorizationException(__('License is not valid.'));
        }
    }
}